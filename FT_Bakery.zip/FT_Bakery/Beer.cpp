
// Beer.cpp

#include "Beer.hpp"

Beer::Beer(double valor): Liquid(valor)
{
	
}