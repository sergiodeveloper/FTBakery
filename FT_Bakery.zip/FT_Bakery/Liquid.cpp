

// Liquid.cpp

#include "Liquid.hpp"

Liquid::Liquid(double valor): Food(valor)
{
	
}

double Liquid::getValor(){
	return valor;
}
