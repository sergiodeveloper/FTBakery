#clear; g++ -std=c++11 a02ex03.cpp a02ex00.cpp a02ex01_a.cpp a02ex03_a.cpp a02ex03_b.cpp a02ex03_c.cpp a02ex03_d.cpp a02ex03_e.cpp -o a02ex03.exe; ./a02ex03.exe 

# adicionado novos arquivos para compilação

clear; g++ -std=c++11 \
	a02ex03.cpp a02ex00.cpp a02ex01_a.cpp a02ex03_a.cpp a02ex03_b.cpp \
	a02ex03_c.cpp a02ex03_d.cpp a02ex03_e.cpp a02ex03_f.cpp a02ex03_g.cpp \
	a02ex03_h.cpp a02ex03_i.cpp \
	MyProgram.cpp FT_bakery.cpp \
	Liquid.cpp Beer.cpp Corona.cpp Brahma.cpp Budweiser.cpp Milk.cpp Soda.cpp \
	StellaArtois.cpp Water.cpp \
	-o a02ex03.exe; ./a02ex03.exe